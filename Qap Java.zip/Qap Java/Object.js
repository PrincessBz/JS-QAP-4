// Name: Princess Bazunu, SD11
// Date: Today
// Motel Customer
let html;
const Customer = {
  name: "Ayomide Zane",
  birthdate: "19-6-1986",
  gender: "Male",
  roompref: ["Exec", "Pres suit", "King", "Double", "Family", "Standard"],
  paymentmethod: "credit Card",
  address: {
    street: "Sandy Cove",
    city: "Eastport",
    province: "NL",
    postal: "A0G3X0",
    country: "Canada",
  },
  phone: +17097987809,

  checkinout: {
    checkin: "2024,3,3",

    checkout: "2024,3,15",
    Time: "12 pm",
  },
  Age: 38,
  durationstay: 12,

  // THIS ONE KEPT COMING BACK WITH A ZERO
  // getAge: function  (){
  //     const today = new Date();
  //     const birthdate = new Date();
  //     let age = today.getFullYear() - birthdate.getFullYear();
  //     const m = today.getMonth() - birthdate.getMonth();
  //     if (m < 0 || (m === 0 && today.getDate() < birthdate.getDate())) {age--;
  //     }
  //    return age; },

  getAge: function (birthdate) {
    const millis = Date.now() - Date.parse(birthdate);
    return new Date().getFullYear() - 1986;
  },

  newDate: function () {
    const checkin = new Date(2024, 3, 3);
    const checkout = new Date(2024, 3, 15);
    const durationMs = checkout - checkin;
    const durationstay = Math.floor(durationMs / (1000 * 60 * 60 * 24));
    return durationstay;
  },

  getDescription: function () {
    return `Mr, ${this.name} ${this.gender} with phone number ${
      this.phone
    },  preferred room ${this.roompref[2]} and payment method ${
      this.paymentmethod
    }, duration of stay ${this.newDate()}days. 
       
       
        Thank you for being our guest.`;
  },
};

// let Val;
// Val = Customer.name;
// Val = Customer.gender;
// Val = Customer.roompref[0];
// Val = Customer.address;
// Val = Customer.newDate();
// Val = Customer.getAge();
// Val = Customer.getDescription();
// html = `<p> ${Val} </p>`

//  let peeps;
//  peeps = Customer.newDate();
// //  peeps = Customer.getAge();
//  console.log(`Customers age: ${peeps}`);
//  console.log(Customer.name);
//  console.log(Customer.roompref[1]);
//  console.log(Customer.paymentmethod);

console.log(Object(Customer));
console.log(Customer.getDescription());
document.body.innerHTML = html;
